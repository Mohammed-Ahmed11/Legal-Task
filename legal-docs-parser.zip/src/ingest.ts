// src/ingest.ts placeholder (full code provided in canvas)
